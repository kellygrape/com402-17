console.log("Hello world");
console.error("Something went wrong!");
